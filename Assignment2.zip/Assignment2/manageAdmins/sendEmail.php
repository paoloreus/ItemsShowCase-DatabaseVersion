<?php

//install phpmailer and use it here