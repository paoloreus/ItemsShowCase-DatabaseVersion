<nav>
    <ul>
        <li><a href="#">Items</a></li>
        <li><a href="#">Categories</a></li>
    </ul>
</nav>